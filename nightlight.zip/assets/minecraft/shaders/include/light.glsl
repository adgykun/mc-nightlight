#version 150

#define MINECRAFT_LIGHT_POWER   (0.6)
#define MINECRAFT_AMBIENT_LIGHT (0.4)

vec4 minecraft_mix_light(vec3 lightDir0, vec3 lightDir1, vec3 normal, vec4 color) {
    float light0 = max(0.0, dot(lightDir0, normal));
    float light1 = max(0.0, dot(lightDir1, normal));
    float lightAccum = min(1.0, (light0 + light1) * MINECRAFT_LIGHT_POWER + MINECRAFT_AMBIENT_LIGHT);
    return vec4(color.rgb * lightAccum, color.a);
}

// 两项参数：blockLight=uv.x(火把/岩浆等), skyLight=uv.y(日光/月光)
// 夜晚地面 skyLight≈4，黄昏/黎明约 8~12，白天=15，全黑洞穴=0。
// 只抬 skyLight 的"夜晚带"，blockLight 不动(火把周围保持原样)。
vec4 minecraft_sample_lightmap(sampler2D lightMap, ivec2 uv) {
    vec2 c = clamp(uv, 0, 15);
    float sky = float(c.y);

    // 钟形平滑曲线：
    //   - 从 sky=0(洞穴全黑)平滑升到 sky=4(夜晚地面)达到最大提亮
    //   - 从 sky=8 起平滑衰减，到 sky=13(白天)完全归零
    // 效果：只提亮夜晚那段，洞穴仍是全黑，白天一点不变，晨昏平滑过渡。
    float rise  = smoothstep(0.0, 4.0, sky);      // 洞穴(0)不提亮，夜晚(4)满额
    float fall  = 1.0 - smoothstep(8.0, 13.0, sky); // 白天(>=13)不提亮
    float boost = 3.5 * rise * fall;              // 适中档：夜晚最多提 3.5 级

    float newSky = min(15.0, sky + boost);
    vec2 newUv = vec2(float(c.x), newSky);
    return texture(lightMap, clamp(newUv / 16.0, vec2(0.5 / 16.0), vec2(15.5 / 16.0)));
}
