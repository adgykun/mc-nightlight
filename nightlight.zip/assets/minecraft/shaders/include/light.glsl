#version 150

#define MINECRAFT_LIGHT_POWER   (0.6)
#define MINECRAFT_AMBIENT_LIGHT (0.4)

vec4 minecraft_mix_light(vec3 lightDir0, vec3 lightDir1, vec3 normal, vec4 color) {
    float light0 = max(0.0, dot(lightDir0, normal));
    float light1 = max(0.0, dot(lightDir1, normal));
    float lightAccum = min(1.0, (light0 + light1) * MINECRAFT_LIGHT_POWER + MINECRAFT_AMBIENT_LIGHT);
    return vec4(color.rgb * lightAccum, color.a);
}

// uv 是 UV2 顶点属性，量程 0-240（每级 16），不是 0-15。
// blockLight=lv.x(火把/岩浆), skyLight=lv.y(日光/月光)，都是 0-15 级。
// 夜晚地面 skyLight≈4，黄昏/黎明约 8~12，白天=15，全黑洞穴=0。
vec4 minecraft_sample_lightmap(sampler2D lightMap, ivec2 uv) {
    vec2 lv = clamp(vec2(uv) / 16.0, 0.0, 15.0);  // 240 -> 15 级
    float sky = lv.y;

    // 钟形平滑：洞穴(0)不提亮 -> 夜晚(4)满额 -> 白天(>=13)归零
    float rise  = smoothstep(0.0, 4.0, sky);
    float fall  = 1.0 - smoothstep(8.0, 13.0, sky);
    lv.y = min(15.0, sky + 3.5 * rise * fall);    // 夜晚 4 级 -> 约 7.5 级

    // 与原版一致：级/16 落在 0.03125~0.96875 覆盖 16 个纹素
    return texture(lightMap, clamp(lv / 16.0, vec2(0.5 / 16.0), vec2(15.5 / 16.0)));
}
